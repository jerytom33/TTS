import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'
import ZAI from 'z-ai-web-dev-sdk'

const ttsRequestSchema = z.object({
  text: z.string().min(1).max(5000),
  voiceId: z.string(),
  speed: z.number().min(0.5).max(2.0).default(1.0),
  pitch: z.number().min(0.5).max(2.0).default(1.0),
  language: z.string().default('en')
})

export async function POST(request: NextRequest) {
  try {
    // Validate authentication
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      )
    }

    const token = authHeader.substring(7)
    
    // Validate session
    const session = await db.userSession.findUnique({
      where: { token },
      include: { user: true }
    })

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Invalid or expired session' },
        { status: 401 }
      )
    }

    // Parse and validate request body
    const body = await request.json()
    const { text, voiceId, speed, pitch, language } = ttsRequestSchema.parse(body)

    // Get voice details
    const voice = await db.voice.findUnique({
      where: { id: voiceId, isActive: true }
    })

    if (!voice) {
      return NextResponse.json(
        { error: 'Voice not found or inactive' },
        { status: 404 }
      )
    }

    // Check rate limiting (simple implementation)
    const recentGenerations = await db.usageAnalytics.count({
      where: {
        userId: session.userId,
        eventType: 'audio_generated',
        createdAt: {
          gte: new Date(Date.now() - 60 * 1000) // Last minute
        }
      }
    })

    if (recentGenerations >= 10) { // Max 10 generations per minute
      return NextResponse.json(
        { error: 'Rate limit exceeded. Please try again later.' },
        { status: 429 }
      )
    }

    // Generate audio using ZAI (Puter.js alternative)
    const zai = await ZAI.create()
    
    // Prepare the prompt for TTS generation
    const ttsPrompt = `Generate high-quality ${language === 'ml' ? 'Malayalam' : 'English'} text-to-speech audio for the following text. Use a ${voice.gender.toLowerCase()} voice with ${speed}x speed and ${pitch}x pitch. The text is: "${text}"`

    try {
      // Generate audio using ZAI
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are a professional text-to-speech AI assistant. Generate high-quality audio that accurately represents the given text with proper pronunciation and emotion.'
          },
          {
            role: 'user',
            content: ttsPrompt
          }
        ],
        max_tokens: 1000,
        temperature: 0.7
      })

      // For demo purposes, we'll simulate audio generation
      // In a real implementation, you would use the actual TTS API
      const audioUrl = `/api/audio/generated/${Date.now()}.mp3`
      const duration = Math.ceil(text.split(' ').length * 0.6) // Estimate duration

      // Log usage analytics
      await db.usageAnalytics.create({
        data: {
          userId: session.userId,
          eventType: 'audio_generated',
          eventData: JSON.stringify({
            voiceId,
            textLength: text.length,
            language,
            duration
          }),
          userAgent: request.headers.get('user-agent') || undefined,
          ipAddress: request.ip || request.headers.get('x-forwarded-for') || undefined
        }
      })

      return NextResponse.json({
        success: true,
        audioUrl,
        duration,
        voiceId,
        textLength: text.length
      })

    } catch (zaiError) {
      console.error('ZAI TTS generation failed:', zaiError)
      
      // Log error
      await db.usageAnalytics.create({
        data: {
          userId: session.userId,
          eventType: 'tts_error',
          eventData: JSON.stringify({
            error: zaiError.message,
            voiceId,
            textLength: text.length
          })
        }
      })

      return NextResponse.json(
        { error: 'Failed to generate audio. Please try again.' },
        { status: 500 }
      )
    }

  } catch (error) {
    console.error('TTS generation error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid request data', details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}